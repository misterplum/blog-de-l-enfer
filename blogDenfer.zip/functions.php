<?php
//récupère tout les articles
function getArticles()
{
	require('connect.php');
	$req = $bdd->prepare('SELECT ID, Titre, Date FROM publications ORDER BY ID DESC');
	$req->execute();
		$data = $req->fetchAll(PDO::FETCH_OBJ);
		return $data;
		$req->closeCursor();
}
//récupère article
function getArticle($ID)
{
	require('connect.php');
	$req = $bdd->prepare('SELECT * FROM publications WHERE id =?');
	$req->execute(array($ID));
	if($req ->rowCount() == 1)
	{
		$data = $req->fetch(PDO :: FETCH_OBJ);
		return $data;
	}
	else
		header('location: index.php');
	$req->closeCursor();
}
// permet d'ajouter un commentaire dans la bdd
function addComment($article_id, $Texte, $Auteur_id)
{
	require('connect.php');
	$req = $bdd->prepare('INSERT INTO commentaires (article_id, Texte, Auteur_id, Date) VALUES (?,?, ?, NOW())');
	$req->execute(array($article_id, $Auteur_id, $Texte));
	$req->closeCursor();
}


// récupère le commentaire d'un article
function getComments($ID)
{
	require('connect.php');
	$req = $bdd->prepare('SELECT * FROM commentaires WHERE article_id = ?');
	$req->execute(array($ID));
	$data = $req->fetchAll(PDO::FETCH_OBJ);	
	return $data;
	$req->closeCursor();
}