<?php
if(!isset($_GET['id']) OR !is_numeric($_GET['id']))
	header('location: index.php');
else{
extract($_GET);
$id = strip_tags($id);

require_once('functions.php');

if (!empty($_POST))
{
	
	extract($_POST);
	$errors = array();
	$auteur = strip_tags($auteur);
	$Texte = strip_tags($Texte);

	if (empty($auteur))
		array_push($errors, 'Entrez votre pseudo');

	if(empty($Texte))
		array_push($errors, 'Entrer un commentaire');
	if(count($errors) == 0)
	{
		$Texte = addComment($id, $auteur, $Texte);

		$succes = 'Votre commentaire a été publié';

		unset($auteur);
		unset($Texte);

		unset($_POST);
	}

}
	$article = getArticle($id);
	$Texte = getComments($id);
}
?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<Titre	><?= $article->Titre ?></Titre>
	</head>

<body>
	<a href="index.php">retour aux articles</a>
	<h1><?= $article->Titre ?></h1>
	<time><?= $article->Date ?></time>
	<p><?= $article->Article ?></p>
	<hr />

<?php
if (isset($success))
	echo $success;

if(!empty($errors)): ?>

	<?php foreach ($errors as $error): ?>
	<p><?= $error ?></p>
	<?php endforeach; ?>

<?php endif; ?>

	<form action="article.php?id=<?= $article->ID ?>" method="post">
		<p><label for="auteur">Pseudo :</label><br />
		<input type="text" name="auteur" ID="auteur" value="<?php if(isset($Auteur_id)) echo $Auteur_id ?>" /></p>
		<p><label for = "Texte">commentaire :</label><br/>
			<textarea name="Texte" id="Texte" cols="30" rows="8"><?php if(isset($_POST['Texte'])) echo $_POST['Texte'] ?></textarea></p>
			<button type="submit" class="btn btn-sucess">envoyer</button>
	</form>

	<h2>Commentaires :</h2>

	<?php foreach($Texte as $com): ?>
		<h3><?= $com->Auteur_id ?></h3>
		<time><?= $com->Date ?></time>
		<p><?= $com->Texte ?></p>
	<?php endforeach; ?>
	</body>

</html>